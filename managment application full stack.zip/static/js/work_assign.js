function openPopup(num) {
  const popup = document.getElementById('popup' + num);
  if (popup) window.workspaceDialogs.open(popup);
}

function closePopup(num) {
  const popup = document.getElementById('popup' + num);
  if (popup) window.workspaceDialogs.close(popup);
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.popup-overlay').forEach((popup) => {
    popup.addEventListener('click', (event) => {
      if (event.target === popup) window.workspaceDialogs.close(popup);
    });
    popup.querySelector('.close-btn')?.setAttribute('aria-label', 'Close assignment form');
  });
});
