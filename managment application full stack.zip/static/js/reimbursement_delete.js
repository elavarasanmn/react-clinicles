(function () {
  function csrfToken() {
    const el = document.querySelector('[name=csrfmiddlewaretoken]');
    return el ? el.value : '';
  }

  function init() {
    // Delete buttons should have data-id
    document.querySelectorAll('button[data-reimbursement-delete]').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault();

        const id = btn.getAttribute('data-id');
        if (!id) return;

        const ok = window.confirm('Delete this reimbursement?');
        if (!ok) return;

        try {
          const res = await fetch(`/superadmin/reinfo_delete/${id}/`, {
            method: 'POST',
            headers: {
              'X-CSRFToken': csrfToken(),
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
          });

          if (!res.ok) {
            const txt = await res.text().catch(() => '');
            alert('Delete failed.' + (txt ? `\n${txt}` : ''));
            return;
          }

          // Refresh page to reflect deletion
          window.location.reload();
        } catch (err) {
          alert('Delete failed.');
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

