document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('printModal');
  if (!modal) return;
  document.getElementById('printBtn')?.addEventListener('click', () => {
    window.workspaceDialogs.open(modal);
  });
  modal.querySelector('.close')?.addEventListener('click', () => {
    window.workspaceDialogs.close(modal);
  });
  modal.addEventListener('click', (event) => {
    if (event.target === modal) window.workspaceDialogs.close(modal);
  });
  document.getElementById('printSubmit')?.addEventListener('click', () => {
    const option = modal.querySelector('input[name="gst"]:checked');
    if (!option) return;
    const params = new URLSearchParams(window.location.search);
    params.set('gst', option.value);
    window.location.href = modal.dataset.printUrl + '?' + params.toString();
  });
});
