// Handles clicking the "Update" button and submits the edited date to backend.
// Current backend expects:
//  - action=update_<id>
//  - date_<id>
//  - hospital_name_<id>
//  - description_<id>
//  - amount_<id>

(function () {
  function onLoad() {
    const forms = document.querySelectorAll('form');

    // Attach a submit handler to forms that contain buttons named action
    forms.forEach((form) => {
      const actionBtn = form.querySelector('button[name="action"]');
      if (!actionBtn) return;

      form.addEventListener('submit', function (e) {
        // Validate that required per-row fields exist for the pressed button
        const btn = form.querySelector('button[name="action"]:focus') || actionBtn;
        // We can’t reliably determine the clicked button in all browsers without focus.
        // Backend reads action from the submitted button value, so do not alter it.
        // Just let the form submit normally.
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onLoad);
  } else {
    onLoad();
  }
})();

