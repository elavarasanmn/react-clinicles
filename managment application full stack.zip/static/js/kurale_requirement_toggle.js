(function () {
  function hide(el) {
    if (el) el.style.display = 'none';
  }

  function show(el) {
    if (el) el.style.display = 'block';
  }

  function initModalToggles() {
    const requirementSelect = document.getElementById('kurale_modal_requirement');
    if (!requirementSelect) return;

    const publicationDiv = document.querySelector('#kuraleAssignedTaskModal .publication');
    const ecDiv = document.querySelector('#kuraleAssignedTaskModal .ec');
    const pptDiv = document.querySelector('#kuraleAssignedTaskModal .ppt');

    if (!publicationDiv || !ecDiv || !pptDiv) return;

    // For safety: ensure sub-sections reflect their internal selects too (Others)
    // (these IDs already existed inline, but we keep behavior consistent)
    const indexingSelect = document.getElementById('kurale_modal_indexing');
    const otherWrap = document.getElementById('kurale_indexing_other_input');
    if (indexingSelect && otherWrap) {
      const syncIndexing = function () {
        otherWrap.style.display = indexingSelect.value === 'Others' ? 'block' : 'none';
      };
      indexingSelect.addEventListener('change', syncIndexing);
      syncIndexing();
    }

    const ecSelect = document.getElementById('kurale_modal_ec');
    const otherWrap1 = document.getElementById('kurale_indexing_other_input1');
    if (ecSelect && otherWrap1) {
      const syncEc = function () {
        otherWrap1.style.display = ecSelect.value === 'Others' ? 'block' : 'none';
      };
      ecSelect.addEventListener('change', syncEc);
      syncEc();
    }

    function syncRequirementDivs() {
      const val = requirementSelect.value;
      hide(publicationDiv);
      hide(ecDiv);
      hide(pptDiv);

      if (val === 'publication') show(publicationDiv);
      else if (val === 'ec') show(ecDiv);
      else if (val === 'ppt') show(pptDiv);
    }

    requirementSelect.addEventListener('change', syncRequirementDivs);
    // also sync on load/when opening modal (handles “already selected” case)
    syncRequirementDivs();
  }

  // If modal contents/select values are set after DOMContentLoaded (when user clicks Edit),
  // ensure we re-sync at the next tick.
  document.addEventListener('change', (e) => {
    const sel = document.getElementById('kurale_modal_requirement');
    if (!sel || e.target !== sel) return;

    const publicationDiv = document.querySelector('#kuraleAssignedTaskModal .publication');
    const ecDiv = document.querySelector('#kuraleAssignedTaskModal .ec');
    const pptDiv = document.querySelector('#kuraleAssignedTaskModal .ppt');
    if (!publicationDiv || !ecDiv || !pptDiv) return;

    publicationDiv.style.display = 'none';
    ecDiv.style.display = 'none';
    pptDiv.style.display = 'none';

    if (sel.value === 'publication') publicationDiv.style.display = 'block';
    else if (sel.value === 'ec') ecDiv.style.display = 'block';
    else if (sel.value === 'ppt') pptDiv.style.display = 'block';
  });

  document.addEventListener('DOMContentLoaded', initModalToggles);
})();


