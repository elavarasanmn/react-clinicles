function openTab(evt, tabName) {
  let i, tabcontent, tablinks;

  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
  const panel = document.getElementById(tabName);
  const statusButton = panel.querySelector('.tablinks1.active') || panel.querySelector('.tablinks1');
  if (statusButton) statusButton.click();
}

function openTab1(evt, tabName) {
  let i, tabcontent, tablinks;

  const panel = evt.currentTarget.closest('.tabcontent');
  tabcontent = panel.getElementsByClassName("tabcontent1");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = panel.getElementsByClassName("tablinks1");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}

function attachTableSearch(searchInputId, tableId) {
  const searchInput = document.getElementById(searchInputId);
  const table = document.getElementById(tableId);

  if (!searchInput || !table) return;

  const tbody = table.tBodies && table.tBodies.length ? table.tBodies[0] : table;
  const rows = tbody.getElementsByTagName("tr");

  searchInput.addEventListener("keyup", function () {
    const query = this.value.trim().toLowerCase();

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowText = row.textContent.toLowerCase();
      row.style.display = rowText.includes(query) ? "" : "none";
    }
  });
}

function showToast(message, isError = false) {
  const toast = document.createElement("div");
  toast.textContent = message;
  toast.style.position = "fixed";
  toast.style.right = "16px";
  toast.style.bottom = "16px";
  toast.style.zIndex = "99999";
  toast.style.padding = "10px 14px";
  toast.style.background = isError ? "#dc3545" : "#28a745";
  toast.style.color = "white";
  toast.style.borderRadius = "6px";
  toast.style.fontSize = "14px";
  toast.style.boxShadow = "0 6px 18px rgba(0,0,0,0.2)";
  toast.style.opacity = "0";
  toast.style.transition = "opacity 150ms ease";

  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    toast.style.opacity = "1";
  });

  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 200);
  }, 2500);
}

document.addEventListener("DOMContentLoaded", function () {
  document.querySelector('.tablinks')?.click();
  // Purplefish search
  attachTableSearch("searchInput1", "dataTable1");
  attachTableSearch("searchInput2", "dataTable2");
  attachTableSearch("searchInput3", "dataTable3");
  attachTableSearch("searchInput4", "dataTable4");
  attachTableSearch("searchInput5", "dataTable5");
  attachTableSearch("searchInput6", "dataTable6");

  // Kurale search
  attachTableSearch("kurSearchInput1", "kurDataTable1");
  attachTableSearch("kurSearchInput2", "kurDataTable2");
  attachTableSearch("kurSearchInput3", "kurDataTable3");
  attachTableSearch("kurSearchInput4", "kurDataTable4");
  attachTableSearch("kurSearchInput5", "kurDataTable5");
  attachTableSearch("kurSearchInput6", "kurDataTable6");

  // Purplefish approve/decline (Pending / Decline tab)
  document.querySelectorAll(".pf-approve-btn, .pf-decline-btn, .pf-decline-approve-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const tr = btn.closest("tr[data-code-no]");
      if (!tr) return;

      const codeNo = tr.getAttribute("data-code-no");
      const action = btn.getAttribute("data-action");
      if (!codeNo || !action) return;

      try {
        btn.disabled = true;

        const res = await fetch("/purplefish/superadmin/pf_work_action", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({ code_no: codeNo, action: action }),
          credentials: "include",
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          alert("Request failed (HTTP " + res.status + "):\n" + t);
          btn.disabled = false;
          return;
        }

        const cells = tr.getElementsByTagName("td");
        const statusCellIndex = 6; // matches your previous logic
        if (cells && cells.length > statusCellIndex) {
          cells[statusCellIndex].textContent = action === "approved" ? "approved" : "declined";
        }

        tr.style.display = "none";
        showToast(action === "approved" ? "Approved" : "Declined");
      } catch (err) {
        btn.disabled = false;
        alert("Error: " + err);
      }
    });
  });

  // Purplefish assigned edit modal
  const modal = document.getElementById("assignedTaskModal");
  const modalClose = document.getElementById("assignedTaskModalClose");
  const modalCancel = document.getElementById("assignedTaskCancelBtn");
  const modalSave = document.getElementById("assignedTaskSaveBtn");

  function setPfModalValuesFromRow(tr) {
    document.getElementById("modal_code_no").value = tr.getAttribute("data-code-no") || "";
    document.getElementById("modal_assigned_date").value = tr.getAttribute("data-assigned-date") || "";
    document.getElementById("modal_end_date").value = tr.getAttribute("data-end-date") || "";
    document.getElementById("modal_work_description").value = tr.getAttribute("data-work-description") || "";

    const proposed = tr.getAttribute("data-proposed-amount") || "";
    const el = document.getElementById("modal_proposed_amount");
    if (el) el.value = proposed;

    document.getElementById("modal_modified_amount").value = tr.getAttribute("data-modified-amount") || "";
    document.getElementById("modal_coordinator").value = tr.getAttribute("data-coordinator") || "";
    document.getElementById("modal_hospital_name").value = tr.getAttribute("data-hospital-name") || "";

    const statusVal = tr.getAttribute("data-work-status") || "";
    const statusEl = document.getElementById("modal_work_status");
    if (statusEl) statusEl.value = statusVal;

    document.getElementById("modal_department").value = tr.getAttribute("data-department") || "";

    const assignedBy = tr.getAttribute("data-assigned-by") || "";
    const assignedByEl = document.getElementById("modal_assigned_by");
    if (assignedByEl) assignedByEl.value = assignedBy;

    const assignedByHidden = document.getElementById("modal_assigned_by_hidden");
    if (assignedByHidden) assignedByHidden.value = assignedBy;
  }

  let pfCurrentRow = null;

  document.querySelectorAll(".pf-edit-assigned-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      pfCurrentRow = btn.closest("tr[data-code-no]");
      if (!pfCurrentRow || !modal) return;
      setPfModalValuesFromRow(pfCurrentRow);
      modal.style.display = "block";
    });
  });

  function closePfModal() {
    if (modal) modal.style.display = "none";
    pfCurrentRow = null;
  }

  if (modalClose) modalClose.addEventListener("click", closePfModal);
  if (modalCancel) modalCancel.addEventListener("click", closePfModal);
  if (modal) {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closePfModal();
    });
  }

  if (modalSave) {
    modalSave.addEventListener("click", async () => {
      if (!pfCurrentRow) return;

      const payload = new URLSearchParams({
        code_no: document.getElementById("modal_code_no").value,
        assigned_date: document.getElementById("modal_assigned_date").value,
        end_date: document.getElementById("modal_end_date").value,
        work_description: document.getElementById("modal_work_description").value,
        modified_amount: document.getElementById("modal_modified_amount").value,
        coordinator: document.getElementById("modal_coordinator").value,
        hospital_name: document.getElementById("modal_hospital_name").value,
        department: document.getElementById("modal_department").value,
        work_status: document.getElementById("modal_work_status").value,
      });

      modalSave.disabled = true;
      try {
        const res = await fetch("/purplefish/superadmin/pf_work_update_assigned", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: payload,
          credentials: "include",
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          alert("Save failed (HTTP " + res.status + "):\n" + t);
          modalSave.disabled = false;
          return;
        }

        showToast("Saved");
        closePfModal();
      } catch (err) {
        alert("Error: " + err);
      } finally {
        modalSave.disabled = false;
      }
    });
  }

  // Purplefish assigned decline
  document.querySelectorAll(".pf-assigned-decline-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const tr = btn.closest("tr[data-code-no]");
      if (!tr) return;

      const codeNo = tr.getAttribute("data-code-no");
      const action = btn.getAttribute("data-action") || "declined";

      try {
        btn.disabled = true;

        const res = await fetch("/purplefish/superadmin/pf_work_action", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({ code_no: codeNo, action: action }),
          credentials: "include",
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          alert("Decline failed (HTTP " + res.status + "):\n" + t);
          btn.disabled = false;
          return;
        }

        tr.style.display = "none";
        showToast("Declined");
      } catch (err) {
        btn.disabled = false;
        alert("Error: " + err);
      }
    });
  });

  // Kurale approve/decline
  document.querySelectorAll(".kur-approve-btn, .kur-decline-btn, .kur-decline-approve-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const tr = btn.closest("tr[data-code-no]");
      if (!tr) return;

      const codeNo = tr.getAttribute("data-code-no");
      const action = btn.getAttribute("data-action");
      if (!codeNo || !action) return;

      try {
        btn.disabled = true;

        const res = await fetch("/purplefish/superadmin/kur_work_action", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({ code_no: codeNo, action: action }),
          credentials: "include",
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          alert("Request failed (HTTP " + res.status + "):\n" + t);
          btn.disabled = false;
          return;
        }

        tr.style.display = "none";
        showToast(action === "approved" ? "Approved" : "Declined");
      } catch (err) {
        btn.disabled = false;
        alert("Error: " + err);
      }
    });
  });

  // Kurale assigned edit modal (Approved Task table)
  const kurModal = document.getElementById("kuraleAssignedTaskModal");
  const kurModalClose = document.getElementById("kuraleAssignedTaskModalClose");
  const kurModalCancel = document.getElementById("kuraleAssignedTaskCancelBtn");
  const kurModalSave = document.getElementById("kuraleAssignedTaskSaveBtn");

  function setKurModalValuesFromRow(tr) {
    const get = (attr) => tr.getAttribute(attr) ?? "";

    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.value = val;
    };

    setVal("kurale_modal_code_no", get("data-code-no"));
    setVal("kurale_modal_assigned_date", get("data-assigned-date"));
    setVal("kurale_modal_end_date", get("data-end-date"));
    setVal("kurale_modal_work_description", get("data-work-description"));

    // address field (from kur_WorkAssignment.address)
    const workAddressVal = get("data-work-address") || get("data-address");
    setVal("kurale_modal_work_address", workAddressVal);

    setVal("kurale_modal_proposed_amount", get("data-proposed-amount"));
    setVal("kurale_modal_modified_amount", get("data-modified-amount"));
    setVal("kurale_modal_coordinator", get("data-coordinator"));
    setVal("kurale_modal_client_name", get("data-client-name"));
    setVal("kurale_modal_title", get("data-title"));

    setVal("kurale_modal_department", get("data-department"));
    const assignedBy = get("data-assigned-by");
    setVal("kurale_modal_assigned_by", assignedBy);
    const assignedByHidden = document.getElementById("kurale_modal_assigned_by_hidden");
    if (assignedByHidden) assignedByHidden.value = assignedBy;

    const statusEl = document.getElementById("kurale_modal_work_status");
    if (statusEl) statusEl.value = get("data-work-status");

    // Extra Kurale fields
    setVal("kurale_modal_phone", get("data-phone"));
    setVal("kurale_modal_email", get("data-email"));
    setVal("kurale_modal_requirement", get("data-requirement"));
    setVal("kurale_modal_milestone", get("data-milestone"));
    setVal("kurale_modal_ec", get("data-ec"));
    setVal("kurale_modal_approval_form", get("data-approval-form"));
    setVal("kurale_modal_invoice_raised", get("data-invoice-raised"));
    setVal("kurale_modal_invoice_status", get("data-invoice-status"));
    setVal("kurale_modal_respective", get("data-respective"));
    setVal("kurale_modal_sharing_invoice_raised", get("data-sharing-invoice-raised"));
    setVal("kurale_modal_sharing_invoice_status", get("data-sharing-invoice-status"));
    setVal("kurale_modal_ppt", get("data-ppt"));
    setVal("kurale_modal_ppt_quot_need", get("data-ppt-quot-need"));
    setVal("kurale_modal_ppt_quot_sent", get("data-ppt-quot-sent"));
    setVal("kurale_modal_ppt_milestone", get("data-ppt-milestone"));

    // Fields that are <select> in HTML (so set value on the select, not hidden inputs)
    const pubSelect = document.getElementById("kurale_modal_publications");
    if (pubSelect) pubSelect.value = get("data-publication-requirement");

    const indexingSelect = document.getElementById("kurale_modal_indexing");
    if (indexingSelect) {
      const indexingVal = get("data-indexing");
      indexingSelect.value = indexingVal;

      const otherInputWrap = document.getElementById("kurale_indexing_other_input");
      if (otherInputWrap) {
        otherInputWrap.style.display = indexingVal === "Others" ? "block" : "none";
      }
    }

    // Visible input when indexing=Others.
    // Template uses kurale_modal_indexing_other, but older versions may use kurale_modal_indexing_other.
    const indexingOtherInput = document.getElementById("kurale_modal_indexing_other") || document.getElementById("kurale_modal_indexing_other");
    if (indexingOtherInput) indexingOtherInput.value = get("data-indexing-other");

    const quotNeedSelect = document.getElementById("kurale_modal_quot_need");

    if (quotNeedSelect) quotNeedSelect.value = get("data-quot-need");

    const quotSentSelect = document.getElementById("kurale_modal_quot_sent");
    if (quotSentSelect) quotSentSelect.value = get("data-quot-sent");
  }

  let kurCurrentRow = null;


  document.querySelectorAll(".kur-edit-assigned-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      kurCurrentRow = btn.closest("tr[data-code-no]");
      if (!kurCurrentRow || !kurModal) return;
      setKurModalValuesFromRow(kurCurrentRow);
      kurModal.style.display = "block";
    });
  });

  function closeKurModal() {
    if (kurModal) kurModal.style.display = "none";
    kurCurrentRow = null;
  }

  if (kurModalClose) kurModalClose.addEventListener("click", closeKurModal);
  if (kurModalCancel) kurModalCancel.addEventListener("click", closeKurModal);
  if (kurModal) {
    kurModal.addEventListener("click", (e) => {
      if (e.target === kurModal) closeKurModal();
    });
  }

  if (kurModalSave) {
    kurModalSave.addEventListener("click", async () => {
      if (!kurCurrentRow) return;

      const payload = new URLSearchParams({
        code_no: document.getElementById("kurale_modal_code_no").value,
        assigned_date: document.getElementById("kurale_modal_assigned_date").value,
        end_date: document.getElementById("kurale_modal_end_date").value,
        work_description: document.getElementById("kurale_modal_work_description").value,
        modified_amount: document.getElementById("kurale_modal_modified_amount").value,
        coordinator: document.getElementById("kurale_modal_coordinator").value,
        hospital_name: document.getElementById("kurale_modal_client_name").value,
        department: document.getElementById("kurale_modal_department").value,
        work_status: document.getElementById("kurale_modal_work_status").value,
        work_address: document.getElementById("kurale_modal_work_address").value,
        title: document.getElementById("kurale_modal_title")?.value || "",
        // Extra Kurale fields
        phone: document.getElementById("kurale_modal_phone")?.value || "",
        email: document.getElementById("kurale_modal_email")?.value || "",
        requirement: document.getElementById("kurale_modal_requirement")?.value || "",
        milestone: document.getElementById("kurale_modal_milestone")?.value || "",
        ec: document.getElementById("kurale_modal_ec")?.value || "",
        approval_form: document.getElementById("kurale_modal_approval_form")?.value || "",
        invoice_raised: document.getElementById("kurale_modal_invoice_raised")?.value || "",
        invoice_status: document.getElementById("kurale_modal_invoice_status")?.value || "",
        respective: document.getElementById("kurale_modal_respective")?.value || "",
        sharing_invoice_raised: document.getElementById("kurale_modal_sharing_invoice_raised")?.value || "",
        sharing_invoice_status: document.getElementById("kurale_modal_sharing_invoice_status")?.value || "",
        ppt: document.getElementById("kurale_modal_ppt")?.value || "",
        ppt_quot_need: document.getElementById("kurale_modal_ppt_quot_need")?.value || "",
        ppt_quot_sent: document.getElementById("kurale_modal_ppt_quot_sent")?.value || "",
        ppt_milestone: document.getElementById("kurale_modal_ppt_milestone")?.value || "",

        // Hidden / existing kurale fields
        publication_requirement: document.getElementById("kurale_modal_publications")?.value || "",
        indexing: document.getElementById("kurale_modal_indexing")?.value || "",
        indexing_other: document.getElementById("kurale_modal_indexing_other")?.value || "",
        quot_need: document.getElementById("kurale_modal_quot_need")?.value || "",
        quot_sent: document.getElementById("kurale_modal_quot_sent")?.value || "",
      });


      kurModalSave.disabled = true;
      try {
        const res = await fetch("/purplefish/superadmin/kur_work_update_assigned", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: payload,
          credentials: "include",
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          alert("Kur save failed (HTTP " + res.status + "):\n" + t);
          kurModalSave.disabled = false;
          return;
        }

        showToast("Saved");
        closeKurModal();
        // simplest: let user refresh to see all server values
      } catch (err) {
        alert("Error: " + err);
      } finally {
        kurModalSave.disabled = false;
      }
    });
  }
});

