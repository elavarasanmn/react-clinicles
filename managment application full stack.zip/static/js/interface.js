// Shared focus handling for assignment and invoice dialogs.
window.workspaceDialogs = (() => {
  let activeDialog = null;
  let trigger = null;
  let previousOverflow = '';
  const focusable = (dialog) => [...dialog.querySelectorAll('button, input:not([type="hidden"]), select, textarea, a[href], [tabindex="0"]')]
    .filter((element) => !element.disabled && element.getClientRects().length > 0);
  const close = (dialog) => {
    dialog.style.display = 'none';
    if (activeDialog === dialog) {
      activeDialog = null;
      document.body.style.overflow = previousOverflow;
      trigger?.focus();
    }
  };
  document.addEventListener('keydown', (event) => {
    if (!activeDialog) return;
    if (event.key === 'Escape') { event.preventDefault(); close(activeDialog); }
    if (event.key !== 'Tab' || !activeDialog) return;
    const elements = focusable(activeDialog);
    const first = elements[0];
    const last = elements[elements.length - 1];
    if (!first) { event.preventDefault(); return; }
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  return {
    open(dialog) {
      if (activeDialog) close(activeDialog);
      trigger = document.activeElement;
      previousOverflow = document.body.style.overflow;
      activeDialog = dialog;
      dialog.setAttribute('role', 'dialog');
      dialog.setAttribute('aria-modal', 'true');
      const title = dialog.querySelector('h2, h3');
      if (title) {
        title.id ||= dialog.id + '-title';
        dialog.setAttribute('aria-labelledby', title.id);
      }
      dialog.style.display = 'flex';
      document.body.style.overflow = 'hidden';
      focusable(dialog)[0]?.focus();
    },
    close,
  };
})();

document.addEventListener('DOMContentLoaded', () => {
  const normalize = (path) => path.replace(/\/+$/, '') || '/';
  document.querySelectorAll('.left_panel_set a, .root_panel nav a').forEach((link) => {
    if (normalize(link.pathname) === normalize(window.location.pathname)) {
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');
    }
  });

  // Keep wide data tables inside the content area, with keyboard-accessible scrolling.
  document.querySelectorAll('.root_panel table').forEach((table) => {
    if (!table.querySelector('thead') || table.closest('.table-scroll')) return;
    const scroller = document.createElement('div');
    scroller.className = 'table-scroll';
    scroller.tabIndex = 0;
    scroller.setAttribute('role', 'region');
    scroller.setAttribute('aria-label', 'Scrollable data table');
    table.before(scroller);
    scroller.append(table);
    const body = table.tBodies[0];
    if (body && body.rows.length === 0) {
      const cell = body.insertRow().insertCell();
      cell.colSpan = table.querySelectorAll('thead th').length || 1;
      cell.textContent = 'No records to display yet.';
      cell.style.textAlign = 'center';
      cell.style.padding = '36px 20px';
    }
  });
});
