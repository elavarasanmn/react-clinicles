from django.shortcuts import render, redirect
from database.models import login, Hospital, pf_get_next_code_no, WorkAssignment, Reimbursement,Invoice,generate_invoice_no,kur_get_next_code_no,kur_WorkAssignment
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.db.models import Count, Sum,Q
from django.utils import timezone
from decimal import Decimal
import json


# Create your views here.


def superadmin_dashboard(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    try:
        user = login.objects.get(id=user_id)
        pf_obj = WorkAssignment.objects.filter(work_status='pending')
        pf_obj_app = WorkAssignment.objects.filter(work_status='approved')
        pf_obj_dec = WorkAssignment.objects.filter(work_status='declined')
        pf_obj_ass = WorkAssignment.objects.filter(work_status='assigned')
        pf_obj_com = WorkAssignment.objects.filter(work_status='completed')
        pf_obj_exp = WorkAssignment.objects.filter(work_status='expired')

        # Kurale (kur_WorkAssignment)
        kur_obj = kur_WorkAssignment.objects.filter(work_status='pending')
        kur_obj_app = kur_WorkAssignment.objects.filter(work_status='approved')
        kur_obj_dec = kur_WorkAssignment.objects.filter(work_status='declined')
        kur_obj_ass = kur_WorkAssignment.objects.filter(work_status='assigned')
        kur_obj_com = kur_WorkAssignment.objects.filter(work_status='completed')
        kur_obj_exp = kur_WorkAssignment.objects.filter(work_status='expired')
        kur_all = kur_WorkAssignment.objects.all().order_by('-id')


        return render(
            request,
            'purplefish/superadmin/dashboard.html',
            {
                'user': user,
                # Purplefish
                'pf': pf_obj,
                'pfa': pf_obj_app,
                'pfd': pf_obj_dec,
                'pfs': pf_obj_ass,
                'pfc': pf_obj_com,
                'pfe': pf_obj_exp,
                # Kurale
                'kur_pf': kur_obj,
                'kur_pfa': kur_obj_app,
                'kur_pfd': kur_obj_dec,
                'kur_pfs': kur_obj_ass,
                'kur_pfc': kur_obj_com,
                'kur_pfe': kur_obj_exp,
            },
        )
    except login.DoesNotExist:
        return redirect('login')


def workassigned(request):
    user_id = request.session.get('user_id')

    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    try:
        user = login.objects.get(id=user_id)
    except login.DoesNotExist:
        return redirect('login')

    next_code_no = pf_get_next_code_no()
    hospitals = Hospital.objects.all()

    # increment code no by creating a record on POST (modal submit)
    if request.method == 'POST':
        code_no = request.POST.get('code_no') or request.POST.get('code_no ') or request.POST.get('code_no[]')
        assigned_date = request.POST.get('assigned_date')

        # NOTE: backend code number generation for KUR happens when code_no is blank,
        # but your KUR popup sends the generated code in a field named `code`.
        end_date = request.POST.get('end_date')

        work_description = request.POST.get('work_description')
        proposed_amount = request.POST.get('proposed_amount')
        modified_amount = request.POST.get('modified_amount')
        hospital_name = request.POST.get('hospital_name')

        WorkAssignment.objects.create(
            code_no=code_no or next_code_no,
            assigned_date=assigned_date,
            end_date=end_date,
            work_description=work_description,
            proposed_amount=proposed_amount,
            modified_amount=modified_amount,
            hospital_name=hospital_name,
            assigned_by=user.username,
        )
        return redirect('purplefish_workassign')

    return render(
        request,
        'purplefish/superadmin/work_assign.html',
        {'user': user, 'next_code_no': next_code_no, 'hospitals': hospitals},
    )



@csrf_exempt
def pf_work_action(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    if request.method != 'POST':
        return redirect('purplefish_superadmin_dashboard')

    code_no = request.POST.get('code_no')
    action = request.POST.get('action')

    if not code_no or not action:
        return redirect('purplefish_superadmin_dashboard')

    try:
        obj = WorkAssignment.objects.get(code_no=code_no)
    except WorkAssignment.DoesNotExist:
        return redirect('purplefish_superadmin_dashboard')

    if action == 'approved':
        obj.work_status = 'approved'
    elif action == 'declined':
        obj.work_status = 'declined'
    else:
        return redirect('purplefish_superadmin_dashboard')

    obj.save()
    return redirect('purplefish_superadmin_dashboard')


@csrf_exempt
def kur_work_action(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    if request.method != 'POST':
        return redirect('purplefish_superadmin_dashboard')

    code_no = request.POST.get('code_no')
    action = request.POST.get('action')

    if not code_no or not action:
        return redirect('purplefish_superadmin_dashboard')

    try:
        obj = kur_WorkAssignment.objects.get(code_no=code_no)
    except kur_WorkAssignment.DoesNotExist:
        return redirect('purplefish_superadmin_dashboard')

    if action == 'approved':
        obj.work_status = 'approved'
    elif action == 'declined':
        obj.work_status = 'declined'
    else:
        return redirect('purplefish_superadmin_dashboard')

    obj.save()
    return redirect('purplefish_superadmin_dashboard')


@csrf_exempt
def kur_work_update_assigned(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    if request.method != 'POST':
        return redirect('purplefish_superadmin_dashboard')

    code_no = request.POST.get('code_no')
    if not code_no:
        return redirect('purplefish_superadmin_dashboard')

    try:
        obj = kur_WorkAssignment.objects.get(code_no=code_no)
    except kur_WorkAssignment.DoesNotExist:
        return redirect('purplefish_superadmin_dashboard')

    assigned_date = request.POST.get('assigned_date')
    end_date = request.POST.get('end_date')
    work_description = request.POST.get('work_description')
    modified_amount = request.POST.get('modified_amount')
    coordinator = request.POST.get('coordinator')
    department = request.POST.get('department')
    work_status = request.POST.get('work_status')
    work_address = request.POST.get('work_address')

    # Extra Kurale fields from modal
    phone = request.POST.get('phone')
    email = request.POST.get('email')
    requirement = request.POST.get('requirement')
    milestone = request.POST.get('milestone')
    ec = request.POST.get('ec')
    approval_form = request.POST.get('approval_form')
    invoice_raised = request.POST.get('invoice_raised')
    invoice_status = request.POST.get('invoice_status')
    respective = request.POST.get('respective')
    sharing_invoice_raised = request.POST.get('sharing_invoice_raised')
    sharing_invoice_status = request.POST.get('sharing_invoice_status')
    ppt = request.POST.get('ppt')
    ppt_quot_need = request.POST.get('ppt_quot_need')
    ppt_quot_sent = request.POST.get('ppt_quot_sent')
    ppt_milestone = request.POST.get('ppt_milestone')

    publication_requirement = request.POST.get('publication_requirement')
    indexing = request.POST.get('indexing')
    indexing_other = request.POST.get('indexing_other')
    quot_need = request.POST.get('quot_need')
    quot_sent = request.POST.get('quot_sent')
    title = request.POST.get('title')

    # When modal fields are empty, Django will still return empty strings.
    # Treat empty strings as "not provided" so existing values are not overwritten.
    def _clean_empty(val):
        return val if val not in (None, '') else None

    publication_requirement = _clean_empty(publication_requirement)
    indexing = _clean_empty(indexing)
    indexing_other = _clean_empty(indexing_other)
    quot_need = _clean_empty(quot_need)
    quot_sent = _clean_empty(quot_sent)


    if assigned_date:
        obj.assigned_date = assigned_date
    if title not in (None, ''):
        obj.title = title


    if end_date:
        obj.end_date = end_date
    if work_description is not None:
        obj.work_description = work_description
    if modified_amount is not None and modified_amount != '':
        obj.modified_amount = modified_amount
    if coordinator is not None:
        obj.coordinator = coordinator
    if department is not None:
        obj.department = department
    if work_status is not None:
        obj.work_status = work_status
    if work_address is not None:
        obj.address = work_address

    # Map remaining fields (only if provided)
    if phone is not None:
        obj.phone = phone
    if email is not None:
        obj.email = email
    if requirement is not None:
        obj.requirement = requirement
    if milestone is not None and milestone != '':
        obj.milestone = milestone
    if ec is not None:
        obj.ec = ec
    if approval_form is not None:
        obj.approval_form = approval_form
    if invoice_raised is not None:
        obj.invoice_raised = invoice_raised
    if invoice_status is not None:
        obj.invoice_status = invoice_status
    if respective is not None:
        obj.respective = respective
    if sharing_invoice_raised is not None:
        obj.sharing_invoice_raised = sharing_invoice_raised
    if sharing_invoice_status is not None:
        obj.sharing_invoice_status = sharing_invoice_status
    if ppt is not None:
        obj.ppt = ppt
    if ppt_quot_need is not None:
        obj.ppt_quot_need = ppt_quot_need
    if ppt_quot_sent is not None:
        obj.ppt_quot_sent = ppt_quot_sent
    if ppt_milestone is not None and ppt_milestone != '':
        obj.ppt_milestone = ppt_milestone

    if publication_requirement is not None:
        obj.publication = publication_requirement
    if indexing is not None:
        obj.indexing = indexing
    if indexing_other is not None:
        obj.indexing_other = indexing_other
    if quot_need is not None:
        obj.quot_need = quot_need
    if quot_sent is not None:
        obj.quot_sent = quot_sent

    obj.save()
    return redirect('purplefish_superadmin_dashboard')



@csrf_exempt
def pf_work_update_assigned(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    if request.method != 'POST':
        return redirect('purplefish_superadmin_dashboard')

    code_no = request.POST.get('code_no')
    if not code_no:
        return redirect('purplefish_superadmin_dashboard')

    try:
        obj = WorkAssignment.objects.get(code_no=code_no)
    except WorkAssignment.DoesNotExist:
        return redirect('purplefish_superadmin_dashboard')

    # Update editable fields (from modal)
    assigned_date = request.POST.get('assigned_date')
    end_date = request.POST.get('end_date')
    work_description = request.POST.get('work_description')
    modified_amount = request.POST.get('modified_amount')
    coordinator = request.POST.get('coordinator')
    hospital_name = request.POST.get('hospital_name')
    department = request.POST.get('department')
    work_status = request.POST.get('work_status')

    if assigned_date:
        obj.assigned_date = assigned_date
    if end_date:
        obj.end_date = end_date
    if work_description is not None:
        obj.work_description = work_description
    if modified_amount is not None and modified_amount != '':
        obj.modified_amount = modified_amount
    if coordinator is not None:
        obj.coordinator = coordinator
    if hospital_name is not None:
        obj.hospital_name = hospital_name
    if department is not None:
        obj.department = department
    if work_status is not None:
        obj.work_status = work_status


    obj.save()
    return redirect('purplefish_superadmin_dashboard')



@csrf_exempt
def kur_dashboard(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    try:
        user = login.objects.get(id=user_id)

        from_date = request.GET.get('from_date')
        to_date = request.GET.get('to_date')
        if from_date in (None, '', 'None'):
            from_date = None
        if to_date in (None, '', 'None'):
            to_date = None

        date_filter = {}
        if from_date and to_date:
            date_filter = {'assigned_date__range': [from_date, to_date]}

        # If you use other semantics like PF pf_dashboard does, you can adjust later.
        kur_all = kur_WorkAssignment.objects.filter(**date_filter)

        total_assignments = kur_all.count()
        pending_assignments = kur_all.filter(work_status='pending').count()
        completed_assignments = kur_all.filter(work_status='completed').count()
        approved_assignments = kur_all.filter(work_status='approved').count()
        declined_assignments = kur_all.filter(work_status='declined').count()
        assigned_assignments = kur_all.filter(work_status='assigned').count()
        expired_assignments = kur_all.filter(work_status='expired').count()

        # counts for Kurale requirement sections
        publication_count = kur_all.filter(requirement = 'publication').count()
        ec_count = kur_all.filter(requirement = 'ec').count()
        ppt_count = kur_all.filter(requirement = 'ppt').count()



        total_proposed = (kur_all.filter(work_status='completed').aggregate(Sum('proposed_amount')).get('proposed_amount__sum')) or 0
        total_modified = (kur_all.filter(work_status='completed').aggregate(Sum('modified_amount')).get('modified_amount__sum')) or 0

        assignments = (
            kur_all.values('assigned_date')
            .annotate(count=Count('id'))
            .order_by('assigned_date')
        )
        scatter_data = []
        for a in assignments:
            date_obj = a['assigned_date']
            date_str = str(date_obj)
            scatter_data.append({'x': date_str, 'y': a['count']})

        context = {
            'user': user,
            'from_date': from_date,
            'to_date': to_date,
            'total_assignments': total_assignments,
            'pending_assignments': pending_assignments,
            'completed_assignments': completed_assignments,
            'approved_assignments': approved_assignments,
            'declined_assignments': declined_assignments,
            'assigned_assignments':assigned_assignments,
            'expired_assignments': expired_assignments,
            'total_proposed': total_proposed,
            'total_modified': total_modified,
            'scatter_data': json.dumps(scatter_data),
            'publication': publication_count,
            'ec': ec_count,
            'ppt': ppt_count,
        }

        return render(request, 'purplefish/superadmin/kur_static.html', context)
    except login.DoesNotExist:
        return redirect('login')


@csrf_exempt
def pf_dashboard(request):
    user_id = request.session.get('user_id')

    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    try:
        user = login.objects.get(id=user_id)

        from_date = request.GET.get('from_date')
        to_date = request.GET.get('to_date')
        if from_date in (None, '', 'None'):
            from_date = None
        if to_date in (None, '', 'None'):
            to_date = None

        date_filter = {}
        if from_date and to_date:
            date_filter = {'assigned_date__range': [from_date, to_date]}

        # Update work_status to 'expire' where end_date is past
        WorkAssignment.objects.filter(
            assigned_by=user.username,
            work_status='assigned',
            end_date__lt=timezone.now().date(),
        ).update(work_status='expired')

        pending_today = WorkAssignment.objects.filter(
            assigned_by=user.username, work_status='assigned', **date_filter
        )
        expired_today = WorkAssignment.objects.filter(
            assigned_by=user.username, work_status='expired', **date_filter
        )

        total_assignments = WorkAssignment.objects.filter(**date_filter).count()
        pending_assignments = WorkAssignment.objects.filter(work_status='pending', **date_filter).count()
        completed_assignments = WorkAssignment.objects.filter(work_status='completed', **date_filter).count()
        approved_assignments = WorkAssignment.objects.filter(work_status='approved', **date_filter).count()
        declined_assignments = WorkAssignment.objects.filter(work_status='declined', **date_filter).count()
        assigned_assignments = WorkAssignment.objects.filter(work_status='assigned', **date_filter).count()
        expired_assignments = WorkAssignment.objects.filter(work_status='expired', **date_filter).count()

        total_hospitals = Hospital.objects.count()

        total_proposed = (
            WorkAssignment.objects.filter(work_status='completed', **date_filter)
            .aggregate(Sum('proposed_amount'))
            .get('proposed_amount__sum')
            or 0
        )
        total_modified = (
            WorkAssignment.objects.filter(work_status='completed', **date_filter)
            .aggregate(Sum('modified_amount'))
            .get('modified_amount__sum')
            or 0
        )

        scatter_data = []
        assignments = (
            WorkAssignment.objects.filter(**date_filter)
            .values('assigned_date')
            .annotate(count=Count('id'))
            .order_by('assigned_date')
        )
        assignments_per_date = {}
        for a in assignments:
            date_obj = a['assigned_date']
            date_str = str(date_obj)
            assignments_per_date[date_str] = a['count']
            scatter_data.append({'x': date_str, 'y': a['count']})

        context = {
            'user': user,
            'notifications': request.session.get('notifications', []),
            'from_date': from_date,
            'to_date': to_date,
            'total_assignments': total_assignments,
            'pending_assignments': pending_assignments,
            'completed_assignments': completed_assignments,
            'approved_assignments': approved_assignments,
            'declined_assignments': declined_assignments,
            'assigned_assignments':assigned_assignments,
            'expired_assignments':expired_assignments,
            'total_hospitals': total_hospitals,
            'total_proposed': total_proposed,
            'total_modified': total_modified,
            'pending_today': pending_today,
            'expired_today': expired_today,
            'assignments_per_date': assignments_per_date,
            'scatter_data': json.dumps(scatter_data),
        }
        return render(request, 'purplefish/superadmin/pf_static.html', context)
    except login.DoesNotExist:
        return redirect('login')




def workassigned(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
    except login.DoesNotExist:
        return redirect('login')
    next_code_no = pf_get_next_code_no()
    kur_next_code_no = kur_get_next_code_no()
    hospitals = Hospital.objects.all()
    if request.method == 'POST':
        code_no = request.POST.get('code_no')
        assigned_date = request.POST.get('assigned_date')
        end_date = request.POST.get('end_date')
        work_description = request.POST.get('work_description')
        proposed_amount = request.POST.get('proposed_amount')
        modified_amount = request.POST.get('modified_amount')
        hospital_name = request.POST.get('hospital_name')
        WorkAssignment.objects.create(
            code_no=code_no,
            assigned_date=assigned_date,
            end_date=end_date,
            work_description=work_description,
            proposed_amount=proposed_amount,
            modified_amount=modified_amount,
            hospital_name=hospital_name,
            assigned_by=user.username,
        )
        return redirect('purplefish_workassign')
    context = {
        'user': user,
        'next_code_no': next_code_no,
        'hospitals': hospitals,
        'kur_next_code_no': kur_next_code_no
    }
    return render(request, 'purplefish/superadmin/work_assign.html',context)

def kur_workassigned(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
    except login.DoesNotExist:
        return redirect('login')
    kur_next_code_no = kur_get_next_code_no()
    if request.method == 'POST':
        code = request.POST.get('code')
        name = request.POST.get('name')
        title = request.POST.get('title')
        assigned_date = request.POST.get('assigned_date')
        ending_date = request.POST.get('ending_date')
        address = request.POST.get('address')
        phonenumber = request.POST.get('phonenumber')
        email = request.POST.get('email')
        work_description = request.POST.get('work_description')
        requirement = request.POST.get('requirement')
        proposed_amount = request.POST.get('proposed_amount')
        modified_amount = request.POST.get('modified_amount')

        kur_WorkAssignment.objects.create(
            code_no=code,
            name=name,
            title = title,
            assigned_date=assigned_date,
            end_date=ending_date,
            address=address,
            phone = phonenumber,
            email=email,
            requirement=requirement,
            work_description=work_description,
            proposed_amount=proposed_amount,
            modified_amount=modified_amount,
            assigned_by=user.username,
        )
        return redirect('purplefish_workassign')
    context = {
        'user': user,
        'kur_next_code_no': kur_next_code_no,
    }
    return render(request, 'purplefish/superadmin/work_assign.html',context)

def kur_task_stat(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')

    user = login.objects.get(id=user_id)
    notifications = request.session.get('notifications', [])
    from_date = request.GET.get('from_date')
    to_date = request.GET.get('to_date')
    search = request.GET.get('search')
    status = request.GET.get('status')
    sort = request.GET.get('sort', 'end_date')
    direction = request.GET.get('direction', 'asc')

    if from_date in ('None', '', None):
        from_date = None
    if to_date in ('None', '', None):
        to_date = None
    if search in ('None', '', None):
        search = None
    if status in ('None', '', None):
        status = None

    date_filter = {}
    if from_date and to_date:
        date_filter = {'assigned_date__range': [from_date, to_date]}

    # Update expire status for end_date passed
    kur_WorkAssignment.objects.filter(
        assigned_by=user.username,
        work_status='assigned',
        end_date__lt=timezone.now().date(),
    ).update(work_status='expired')

    order_by = sort if direction == 'asc' else f'-{sort}'
    all_tasks = kur_WorkAssignment.objects.filter(**date_filter).order_by(order_by)

    if status:
        all_tasks = all_tasks.filter(work_status=status)

    if search:
        all_tasks = all_tasks.filter(
            Q(code_no__icontains=search) |
            Q(work_description__icontains=search) |
            Q(requirement__icontains=search) |
            Q(assigned_by__icontains=search) |
            Q(name__icontains=search)
        )

    pending_tasks = all_tasks.filter(Q(work_status='assigned') | Q(work_status='pending'))
    completed_tasks = all_tasks.filter(work_status='completed')
    approved_tasks = all_tasks.filter(work_status='approved')
    declined_tasks = all_tasks.filter(work_status='declined')
    expired_tasks = all_tasks.filter(work_status='expired')

    context = {
        'user': user,
        'notifications': notifications,
        'all_tasks': all_tasks,
        'pending_tasks': pending_tasks,
        'completed_tasks': completed_tasks,
        'approved_tasks': approved_tasks,
        'declined_tasks': declined_tasks,
        'expired_tasks': expired_tasks,
        'from_date': from_date,
        'to_date': to_date,
        'search': search,
        'status': status,
        'sort': sort,
        'direction': direction,
    }
    return render(request, 'purplefish/superadmin/kur_task.html', context)




def pf_task_stat(request):
    # NOTE: kept for compatibility (Purplefish tasks page)
    # Kurale tasks page is kur_task_stat

    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
        notifications = request.session.get('notifications', [])
        from_date = request.GET.get('from_date')
        to_date = request.GET.get('to_date')
        search = request.GET.get('search')
        status = request.GET.get('status')
        sort = request.GET.get('sort', 'end_date')
        direction = request.GET.get('direction', 'asc')
        if from_date == 'None' or not from_date:
            from_date = None
        if to_date == 'None' or not to_date:
            to_date = None
        if search == 'None' or not search:
            search = None
        if status == 'None' or not status:
            status = None
        date_filter = {}
        if from_date and to_date:
            date_filter = {'assigned_date__range': [from_date, to_date]}

        # Update work_status to 'expire' for tasks where end_date is past the current date
        WorkAssignment.objects.filter(
            assigned_by=user.username, work_status='assigned', end_date__lt=timezone.now().date()
        ).update(work_status='expired')

        # Fetch all tasks filtered by date range or all
        order_by = sort if direction == 'asc' else f'-{sort}'
        all_tasks = WorkAssignment.objects.filter(**date_filter).order_by(order_by)
        if status:
            all_tasks = all_tasks.filter(work_status=status)
        if search:
            all_tasks = all_tasks.filter(
                Q(code_no__icontains=search) |
                Q(work_description__icontains=search) |
                Q(hospital_name__icontains=search) |
                Q(assigned_by__icontains=search)
            )
        pending_tasks = all_tasks.filter(Q(work_status='assigned') | Q(work_status='pending'))
        completed_tasks = all_tasks.filter(work_status='completed')
        approved_tasks = all_tasks.filter(work_status='approved')
        declined_tasks = all_tasks.filter(work_status='declined')
        expired_tasks = all_tasks.filter(work_status='expired')

        context = {
            'user': user,
            'notifications': notifications,
            'all_tasks': all_tasks,
            'pending_tasks': pending_tasks,
            'completed_tasks': completed_tasks,
            'approved_tasks': approved_tasks,
            'declined_tasks': declined_tasks,
            'expired_tasks': expired_tasks,
            'from_date': from_date,
            'to_date': to_date,
            'search': search,
            'status': status,
            'sort': sort,
            'direction': direction,
        }
        return render(request, 'purplefish/superadmin/pf_task.html', context)
    except login.DoesNotExist:
        return redirect('login')


def hospital_list_view(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
        if request.method == 'POST':
            action = request.POST.get('action')
            if action == 'add':
                name = request.POST.get('name')
                address = request.POST.get('address')
                contact_number = request.POST.get('contact_number')
                doctor_in_charge = request.POST.get('doctor_in_charge')
                try:
                    Hospital.objects.create(
                        name=name,
                        address=address,
                        contact_number=contact_number,
                        doctor_in_charge=doctor_in_charge
                    )
                    return redirect('hospital_list')
                except Exception as e:
                    # Handle errors, e.g., unique constraint violations
                    pass
            elif action == 'update':
                hospital_id = request.POST.get('hospital_id')
                name = request.POST.get('name')
                address = request.POST.get('address')
                contact_number = request.POST.get('contact_number')
                doctor_in_charge = request.POST.get('doctor_in_charge')
                try:
                    hospital = Hospital.objects.get(id=hospital_id)
                    hospital.name = name
                    hospital.address = address
                    hospital.contact_number = contact_number
                    hospital.doctor_in_charge = doctor_in_charge
                    hospital.save()
                    return redirect('hospital_list')
                except Hospital.DoesNotExist:
                    pass
            elif action == 'delete':
                hospital_id = request.POST.get('hospital_id')
                try:
                    hospital = Hospital.objects.get(id=hospital_id)
                    hospital.delete()
                    return redirect('hospital_list')
                except Hospital.DoesNotExist:
                    pass
        hospitals = Hospital.objects.all()
        
        return render(request, 'purplefish/superadmin/hospital_list.html', {'user': user, 'hospitals': hospitals})
    except login.DoesNotExist:
        return redirect('login')
    
@csrf_exempt
def reinfo_delete(request, reimbursement_id):
    # Handles AJAX delete
    if request.method != 'POST':
        return redirect('reinfo')

    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')

    user = login.objects.get(id=user_id)
    obj = Reimbursement.objects.get(id=reimbursement_id, user=user)
    obj.delete()
    return redirect('reinfo')


def reinfo(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
        notifications = request.session.get('notifications', [])
        hospitals = Hospital.objects.all()
        if request.method == 'POST':
            action = request.POST.get('action')
            if action and action.startswith('update_'):
                # Handle update from table row
                reimbursement_id = action.split('_')[-1]
                try:
                    reimbursement = Reimbursement.objects.get(id=reimbursement_id, user=user)

                    # read per-row fields
                    reimbursement.hospital_name = request.POST.get(f'hospital_name_{reimbursement_id}')

                    # date input must be YYYY-MM-DD. If empty or invalid, don’t overwrite existing value.
                    raw_date = request.POST.get(f'date_{reimbursement_id}')
                    if raw_date:
                        reimbursement.date = raw_date

                    reimbursement.description = request.POST.get(f'description_{reimbursement_id}')
                    reimbursement.amount = request.POST.get(f'amount_{reimbursement_id}')

                    # ensure we persist changes
                    reimbursement.save()

                    notifications.append({
                        'title': 'Reimbursement Updated',
                        'message': 'Your reimbursement request has been updated successfully.',
                        'timestamp': timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                    })
                    request.session['notifications'] = notifications
                    return redirect('reinfo')
                except Reimbursement.DoesNotExist:
                    notifications.append({
                        'title': 'Update Failed',
                        'message': 'Reimbursement not found.',
                        'timestamp': timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                    })
                    request.session['notifications'] = notifications
                    return redirect('reinfo')
            # Check if it's a new submission or inline edit
            date = request.POST.get('date')
            description = request.POST.get('description')
            amount = request.POST.get('amount')
            hospital_name = request.POST.get('hospital_name')
            reimbursement_id = request.POST.get('reimbursement_id')

            if date and description and amount and hospital_name:
                # New submission or edit from form
                if reimbursement_id:
                    # Update existing reimbursement
                    try:
                        reimbursement = Reimbursement.objects.get(id=reimbursement_id, user=user)
                        reimbursement.date = date
                        reimbursement.description = description
                        reimbursement.amount = amount
                        reimbursement.hospital_name = hospital_name
                        reimbursement.save()
                        message = 'Your reimbursement request has been updated successfully.'
                    except Reimbursement.DoesNotExist:
                        message = 'Reimbursement not found.'
                else:
                    # Create new reimbursement
                    Reimbursement.objects.create(
                        user=user,
                        date=date,
                        description=description,
                        amount=amount,
                        hospital_name=hospital_name
                    )
                    message = 'Your reimbursement request has been submitted successfully.'
                # Add success message to notifications
                notifications.append({
                    'title': 'Reimbursement ' + ('Updated' if reimbursement_id else 'Submitted'),
                    'message': message,
                    'timestamp': timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                })
                request.session['notifications'] = notifications
                return redirect('reinfo')
            else:
                # Handle inline edits
                updated_count = 0
                for key, value in request.POST.items():
                    if key.startswith('hospital_name_') and value:
                        reimbursement_id = key.split('_')[-1]
                        try:
                            reimbursement = Reimbursement.objects.get(id=reimbursement_id, user=user)
                            reimbursement.hospital_name = value
                            reimbursement.date = request.POST.get(f'date_{reimbursement_id}')
                            reimbursement.description = request.POST.get(f'description_{reimbursement_id}')
                            reimbursement.amount = request.POST.get(f'amount_{reimbursement_id}')
                            reimbursement.save()
                            updated_count += 1
                        except Reimbursement.DoesNotExist:
                            pass
                if updated_count > 0:
                    notifications.append({
                        'title': 'Reimbursements Updated',
                        'message': f'{updated_count} reimbursement(s) have been updated successfully.',
                        'timestamp': timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                    })
                    request.session['notifications'] = notifications
                    return redirect('reinfo')
        # Handle GET request (show all reimbursements)
        reimbursements = Reimbursement.objects.all().order_by('-created_at')
        context = {
            'user': user,
            'notifications': notifications,
            'hospitals': hospitals,
            'reimbursements': reimbursements,
        }
        return render(request, 'purplefish/superadmin/reinvesment.html', context)
    except login.DoesNotExist:
        return redirect('login')
    
def invoice(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
        notifications = request.session.get('notifications', [])
        hospitals = Hospital.objects.all()
        reimbursements = Reimbursement.objects.filter(status='completed').order_by('-created_at')
        completed_tasks = WorkAssignment.objects.filter(work_status='completed').order_by('-end_date')

        # Get filter parameters
        hospital_name = request.GET.get('hospital_name')
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')
        with_gst = request.GET.get('with_gst') == 'on'
        without_gst = request.GET.get('without_gst') == 'on'

        # Apply filters
        if hospital_name:
            reimbursements = reimbursements.filter(hospital_name=hospital_name)
            completed_tasks = completed_tasks.filter(hospital_name=hospital_name)
        if start_date and end_date:
            reimbursements = reimbursements.filter(date__range=[start_date, end_date])
            completed_tasks = completed_tasks.filter(end_date__range=[start_date, end_date])

        # Calculate totals
        total_amount = reimbursements.aggregate(Sum('amount'))['amount__sum'] or 0
        total_tasks_amount = completed_tasks.aggregate(Sum('modified_amount'))['modified_amount__sum'] or 0
        gst_amount = total_amount * Decimal('0.18')
        total_with_gst = total_amount + gst_amount

        users = login.objects.all()

        context = {
            'user': user,
            'notifications': notifications,
            'hospitals': hospitals,
            'reimbursements': reimbursements,
            'completed_tasks': completed_tasks,
            'total_amount': total_amount,
            'total_tasks_amount': total_tasks_amount,
            'gst_amount': gst_amount,
            'total_with_gst': total_with_gst,
            'users': users,
        }
        return render(request, 'purplefish/superadmin/invoice.html', context)
    except login.DoesNotExist:
        return redirect('login')

def invoice_print(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
        hospitals = Hospital.objects.all()
        users = login.objects.all()
        reimbursements = Reimbursement.objects.filter(status='completed').order_by('-created_at')
        completed_tasks = WorkAssignment.objects.filter(work_status='completed').order_by('-end_date')

        # Get filter parameters
        hospital_name = request.GET.get('hospital_name')
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')
        gst = request.GET.get('gst', 'without')

        # Get selected hospital if any
        selected_hospital = None
        if hospital_name:
            try:
                selected_hospital = Hospital.objects.get(name=hospital_name)
            except Hospital.DoesNotExist:
                selected_hospital = None

        # Apply filters
        if hospital_name:
            reimbursements = reimbursements.filter(hospital_name=hospital_name)
            completed_tasks = completed_tasks.filter(hospital_name=hospital_name)
        if start_date and end_date:
            reimbursements = reimbursements.filter(date__range=[start_date, end_date])
            completed_tasks = completed_tasks.filter(end_date__range=[start_date, end_date])

        # Calculate totals
        total_amount = reimbursements.aggregate(Sum('amount'))['amount__sum'] or 0
        total_tasks_amount = completed_tasks.aggregate(Sum('modified_amount'))['modified_amount__sum'] or 0
        gst_amount = total_amount * Decimal('0.18')
        total_with_gst = total_amount + gst_amount

        # Generate invoice number
        invoice_no = generate_invoice_no()
        from datetime import datetime
        today = datetime.now().date()
        invoice_date = today.strftime('%Y-%m-%d')

        # Save invoice data to database
        Invoice.objects.create(
            invoice_no=invoice_no,
            date=today,
            hospital=selected_hospital,
            total_amount=total_amount,
            gst_amount=gst_amount,
            total_with_gst=total_with_gst,
            user=user
        )

        context = {
            'user': user,
            'hospitals': hospitals,
            'users': users,
            'reimbursements': reimbursements,
            'completed_tasks': completed_tasks,
            'total_amount': total_amount,
            'total_tasks_amount': total_tasks_amount,
            'gst_amount': gst_amount,
            'total_with_gst': total_with_gst,
            'gst': gst,
            'invoice_no': invoice_no,
            'invoice_date': invoice_date,
            'selected_hospital': selected_hospital,
        }
        if gst == 'with':
            return render(request, 'purplefish/superadmin/invoice_print_with_gst.html', context)
        else:
            return render(request, 'purplefish/superadmin/invoice_print_without_gst.html', context)
    except login.DoesNotExist:
        return redirect('login')

def invoice_history(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')
    try:
        user = login.objects.get(id=user_id)
        notifications = request.session.get('notifications', [])
        invoices = Invoice.objects.filter(user=user).order_by('-created_at')

        # Search functionality
        search_query = request.GET.get('search')
        if search_query:
            invoices = invoices.filter(
                Q(invoice_no__icontains=search_query) |
                Q(hospital__name__icontains=search_query)
            )

        # Date filtering
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')
        if start_date:
            invoices = invoices.filter(date__gte=start_date)
        if end_date:
            invoices = invoices.filter(date__lte=end_date)

        context = {
            'user': user,
            'notifications': notifications,
            'invoices': invoices,
            'request': request,
        }
        return render(request, 'purplefish/superadmin/invoice_history.html', context)
    except login.DoesNotExist:
        return redirect('login')

def invoice_download(request, invoice_id):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')
    try:
       
        invoice = Invoice.objects.get(id=invoice_id)
        selected_hospital = invoice.hospital
        invoice_no = invoice.invoice_no
        invoice_date = invoice.date.strftime('%Y-%m-%d')

        # Fetch completed tasks and reimbursements based on invoice's hospital and date
        completed_tasks = WorkAssignment.objects.filter(
            work_status='completed'
        )
        reimbursements = Reimbursement.objects.filter(
            status='completed'
        )
        if selected_hospital:
            completed_tasks = completed_tasks.filter(hospital_name=selected_hospital.name)
            reimbursements = reimbursements.filter(hospital_name=selected_hospital.name)

        # Filter by month and year of invoice date
        completed_tasks = completed_tasks.filter(
            end_date__month=invoice.date.month, end_date__year=invoice.date.year
        )
        reimbursements = reimbursements.filter(
            date__month=invoice.date.month, date__year=invoice.date.year
        )

        total_tasks_amount = completed_tasks.aggregate(Sum('modified_amount'))['modified_amount__sum'] or 0
        total_amount = reimbursements.aggregate(Sum('amount'))['amount__sum'] or 0

        context = {
            'selected_hospital': selected_hospital,
            'invoice_no': invoice_no,
            'invoice_date': invoice_date,
            'total_tasks_amount': total_tasks_amount,
            'total_amount': total_amount,
            'completed_tasks': completed_tasks,
            'reimbursements': reimbursements,
        }
        return render(request, 'purplefish/superadmin/invoice_download.html', context)
    except (login.DoesNotExist, Invoice.DoesNotExist):
        return redirect('invoice_history')

def employee(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')
    user = login.objects.get(id=user_id)
    user_obj = login.objects.all()
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        role = request.POST.get('role')
        depatment = request.POST.get('depatment')
        login.objects.create(
            username = username,
            password = password,
            role = role,
            depatment = depatment
        )
    context = {
         'user': user,  
         'usr': user_obj
    }

    return render(request,'purplefish/superadmin/employee.html',context)
def kur_invoice_print(request):
    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    user = login.objects.get(id=user_id)
    notifications = request.session.get('notifications', [])

    reimbursements = Reimbursement.objects.filter(status='completed').order_by('-created_at')
    completed_tasks = kur_WorkAssignment.objects.filter(work_status='completed').order_by('-end_date')

    code_no = request.GET.get('code_no') or request.GET.get('client_name')
    if code_no:
        reimbursements = reimbursements.filter(description__icontains=code_no)
        completed_tasks = completed_tasks.filter(code_no__icontains=code_no)

    total_amount = reimbursements.aggregate(Sum('amount'))['amount__sum'] or 0
    total_tasks_amount = completed_tasks.aggregate(Sum('modified_amount'))['modified_amount__sum'] or 0

    gst = request.GET.get('gst', 'without')

    from datetime import datetime
    today = datetime.now().date()
    invoice_date = today.strftime('%Y-%m-%d')

    # Reuse existing invoice number generator format
    invoice_no = generate_invoice_no()

    # NOTE: Invoice model is generic (PF). Keeping kur print independent of DB write.

    # address is stored per task (kur_WorkAssignment.address). For invoice print, show the first matching task's address.
    address = None
    if completed_tasks:
        first_task = completed_tasks.first()
        if first_task:
            address = first_task.address

    context = {
        'user': user,
        'notifications': notifications,
        'code_no': code_no,
        'invoice_no': invoice_no,
        'invoice_date': invoice_date,
        'reimbursements': reimbursements,
        'completed_tasks': completed_tasks,
        'total_amount': total_amount,
        'total_tasks_amount': total_tasks_amount,
        'gst': gst,
        'gst_amount': total_amount * Decimal('0.18'),
        'total_with_gst': total_amount + (total_amount * Decimal('0.18')),
        'address': address,
    }

    if gst == 'with':
        return render(request, 'purplefish/superadmin/kur_invoice_print_with_gst.html', context)
    return render(request, 'purplefish/superadmin/kur_invoice_print_without_gst.html', context)


def kur_invoice(request):

    user_id = request.session.get('user_id')
    user_name = request.session.get('username')
    user_role = request.session.get('role')
    if not user_id:
        return redirect('login')
    if not user_name or user_role != 'superadmin':
        messages(request, 'user not found')
        return redirect('login')

    user = login.objects.get(id=user_id)
    notifications = request.session.get('notifications', [])

    hospitals = Hospital.objects.all()
    reimbursements = Reimbursement.objects.filter(status='completed').order_by('-created_at')
    completed_tasks = kur_WorkAssignment.objects.filter(work_status='completed').order_by('-end_date')

    # Kurale invoice filtering:
    # - filter by code_no (entered in UI as client_name field, updated to code_no)
    code_no = request.GET.get('code_no') or request.GET.get('client_name')

    if code_no:
        reimbursements = reimbursements.filter(description__icontains=code_no)
        completed_tasks = completed_tasks.filter(code_no__icontains=code_no)

    total_amount = reimbursements.aggregate(Sum('amount'))['amount__sum'] or 0
    total_tasks_amount = completed_tasks.aggregate(Sum('modified_amount'))['modified_amount__sum'] or 0

    context = {
        'user': user,
        'notifications': notifications,
        'hospitals': hospitals,
        'reimbursements': reimbursements,
        'completed_tasks': completed_tasks,
        'total_amount': total_amount,
        'total_tasks_amount': total_tasks_amount,
    }
    return render(request, 'purplefish/superadmin/kurinvoice.html', context)


