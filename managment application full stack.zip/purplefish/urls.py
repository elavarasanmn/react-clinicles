from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('superadmin/dashboard/', views.superadmin_dashboard, name='purplefish_superadmin_dashboard'),
    path('superadmin/workassign', views.workassigned, name='purplefish_workassign'),
    path('superadmin/hospital_list/', views.hospital_list_view, name='hospital_list'),
    path('superadmin/reinfo/',views.reinfo,name='reinfo'),
    path('superadmin/reinfo_delete/<int:reimbursement_id>/', views.reinfo_delete, name='reinfo_delete'),
    path('superadmin/invoice/',views.invoice,name='invoice'),
    path('superadmin/invoice_print/',views.invoice_print,name='invoice_print'),
    path('superadmin/invoice_history/',views.invoice_history,name='invoice_history'),
    path('superadmin/invoice_download/<int:invoice_id>/', views.invoice_download, name='invoice_download'),
    path('superadmin/kurale/',views.kur_workassigned,name='kur_workassigned'),
    path('superadmin/kur_task/', views.kur_task_stat, name='kur_task_status'),

    # Purplefish statistics dashboard page (pf_static.html)

    path('superadmin/pf_static/', views.pf_dashboard, name='dashboard'),

    # Kurale statistics page (kur_static.html)
    path('superadmin/kur_static/', views.kur_dashboard, name='kur_dashboard'),


    # Keep existing routes for compatibility with current JS/templates
    path('superadmin/pf_work_store', views.workassigned, name="pf_work_assign"),


    # Task status page (pf_task.html)
    path('superadmin/pf_task_status/', views.pf_task_stat, name='task_status'),


    path('superadmin/pf_work_action', views.pf_work_action, name='pf_work_action'),
    path('superadmin/pf_work_update_assigned', views.pf_work_update_assigned, name='pf_work_update_assigned'),

    # Kurale approve/decline + assigned update
    path('superadmin/kur_work_action', views.kur_work_action, name='kur_work_action'),
    path('superadmin/kur_work_update_assigned', views.kur_work_update_assigned, name='kur_work_update_assigned'),

    path('superadmin/employee/', views.employee, name ='employee'),
    path('superadmin/kurale_invoice',views.kur_invoice, name='kurinvoice'),
    path('superadmin/kurale_invoice_print/', views.kur_invoice_print, name='kur_invoice_print'),
]









