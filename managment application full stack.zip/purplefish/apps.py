from django.apps import AppConfig


class PurplefishConfig(AppConfig):
    name = 'purplefish'
