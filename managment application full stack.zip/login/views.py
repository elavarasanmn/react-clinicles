from django.shortcuts import render,redirect
from database.models import login, pf_get_next_code_no,Hospital
from django.contrib import messages


# Create your views here.
def login_view(request):
    # Prevent redirect loops:
    # dashboard URL uses this same view, so redirecting back to it causes infinite redirects.
    if request.session.get('user_id'):
        if request.path.endswith('/purplefish/superadmin/dashboard/'):
            return render(request, 'purplefish/superadmin/dashboard.html')
        return redirect('purplefish_superadmin_dashboard')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            user_obj = login.objects.get(username=username, password=password)
            request.session['user_id'] = user_obj.id
            request.session['username'] = user_obj.username
            request.session['role'] = user_obj.role
            request.session.set_expiry(7776000000)  # Session expires in ~90 days

            if user_obj.depatment == 'purplefish' and user_obj.role == 'superadmin':
                return render(request, 'purplefish/superadmin/dashboard.html')
            elif user_obj.depatment == 'purplefish' and user_obj.role == 'admin':
                return render(request, 'purplefish/admin/dashboard.html')
            elif user_obj.depatment == 'purplefish' and user_obj.role == 'employee':
                return render(request, 'purplefish/employee/dashboard.html')
            
            else:
                messages.error(request, 'You do not have permission to access the dashboard.')
                return render(request, 'login/login.html')

        except login.DoesNotExist:
            messages.error(request, 'Invalid username or password.')
            return render(request, 'login/login.html')
    
    return render(request,'login/login.html')

