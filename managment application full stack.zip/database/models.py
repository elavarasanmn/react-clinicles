from django.db import models


def pf_generate_code_no():
    # Get the last WorkAssignment
    last_assignment = WorkAssignment.objects.order_by('-id').first()
    if last_assignment and last_assignment.code_no.startswith('PF'):
        try:
            # Extract the number part and increment
            num = int(last_assignment.code_no[2:]) + 1
        except ValueError:
            num = 1
    else:
        num = 1
    # Format as PF followed by 3-digit number
    return f"PF{num:03d}"

def pf_get_next_code_no():
    # Get the next code without saving
    last_assignment = WorkAssignment.objects.order_by('-id').first()
    if last_assignment and last_assignment.code_no.startswith('PF'):
        try:
            num = int(last_assignment.code_no[2:]) + 1
        except ValueError:
            num = 1
    else:
        num = 1
    return f"PF{num:03d}"

def generate_invoice_no():
    # Dynamic invoice number generation starting from PF-INV-1
    existing_invoices = Invoice.objects.filter(invoice_no__startswith='PF-INV-')
    if existing_invoices.exists():
        # Extract numbers and find the max
        numbers = []
        for inv in existing_invoices:
            try:
                num = int(inv.invoice_no[7:])  # 'PF-INV-' is 7 chars
                numbers.append(num)
            except ValueError:
                continue
        if numbers:
            next_num = max(numbers) + 1
        else:
            next_num = 1
    else:
        next_num = 1
    return f"PF-INV-{next_num}"

def kur_generate_code_no():
    # Get the last WorkAssignment
    last_assignment = kur_WorkAssignment.objects.order_by('-id').first()
    if last_assignment and last_assignment.code_no.startswith('KUR'):
        try:
            # Extract the number part and increment
            num = int(last_assignment.code_no[2:]) + 1
        except ValueError:
            num = 1
    else:
        num = 1
    # Format as PF followed by 3-digit number
    return f"KUR{num:03d}"
# Create your models here.

def kur_get_next_code_no():
    """Return the next KUR code (e.g., KUR001 -> KUR002).

    Uses the maximum numeric part across existing rows to avoid
    issues caused by insert order.
    """
    max_num = 0
    for a in kur_WorkAssignment.objects.only('code_no'):
        code = (a.code_no or '').strip()
        if code.startswith('KUR'):
            try:
                n = int(code[3:])  # after 'KUR'
            except ValueError:
                continue    
            max_num = max(max_num, n)

    return f"KUR{max_num + 1:03d}"

class login(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    role = models.CharField(max_length=50)
    depatment = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username

class WorkAssignment(models.Model):
    # s_no = models.IntegerField()
    code_no = models.CharField(max_length=100, unique=True, blank=True)
    assigned_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    work_description = models.TextField(blank=True, null=True)
    proposed_amount = models.DecimalField(max_digits=10, decimal_places=2)
    modified_amount = models.DecimalField(max_digits=10, decimal_places=2)
    work_status = models.CharField(max_length=50, default='pending')
    coordinator = models.CharField(max_length=100, default='none')
    hospital_name = models.CharField(max_length=100)
    department = models.CharField(max_length=50, default="Purple_Fish")
    assigned_by = models.CharField(max_length=70,default="none")

    def save(self, *args, **kwargs):
        if not self.code_no:
            self.code_no = pf_generate_code_no()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.code_no} - {self.work_description[:50]}"
    
class kur_WorkAssignment(models.Model):
    # s_no = models.IntegerField()
    code_no = models.CharField(max_length=100, unique=True, blank=True)
    name = models.CharField(max_length=100,blank=True,null=True)
    title = models.CharField(max_length=100,blank=True,null=True)
    assigned_date = models.DateField()
    end_date = models.DateField()
    address = models.TextField(blank=True,null=True)
    phone = models.CharField(max_length=15,blank=True,null=True)
    email = models.EmailField(blank=True,null=True)
    work_description = models.TextField(blank=True,null=True)
    requirement = models.TextField(blank=True,null=True)
    publication= models.CharField(max_length=200,blank=True,null=True)
    indexing= models.CharField(max_length=200,blank=True,null=True)
    quot_need = models.CharField(max_length=200,blank=True,null=True)
    quot_sent =models.CharField(max_length=200,blank=True,null=True)
    milestone  = models.IntegerField(max_length=200,blank=True,null=True)
    ec = models.CharField(max_length=200,blank=True,null=True)
    approval_form =models.CharField(max_length=200,blank=True,null=True)
    invoice_raised  =models.CharField(max_length=200,blank=True,null=True)
    respective =models.CharField(max_length=200,blank=True,null=True)
    invoice_status =models.CharField(max_length=200,blank=True,null=True)
    sharing_invoice_raised =models.CharField(max_length=200,blank=True,null=True)
    sharing_invoice_status  =models.CharField(max_length=200,blank=True,null=True)
    ppt =  models.CharField(max_length=200,blank=True,null=True)
    ppt_quot_need = models.CharField(max_length=200,blank=True,null=True)
    ppt_quot_sent =models.CharField(max_length=200,blank=True,null=True)
    ppt_milestone  = models.IntegerField(max_length=200,blank=True,null=True)
    proposed_amount = models.DecimalField(max_digits=10, decimal_places=2)
    modified_amount = models.DecimalField(max_digits=10, decimal_places=2)
    work_status = models.CharField(max_length=50, default='pending')
    coordinator = models.CharField(max_length=100, default='none')
    department = models.CharField(max_length=50, default="Kurale")
    assigned_by = models.CharField(max_length=70,default="none")

    def save(self, *args, **kwargs):
        if not self.code_no:
            self.code_no = kur_generate_code_no()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.code_no} - {self.work_description[:50]}"
    
class Hospital(models.Model):
    name = models.CharField(max_length=200)
    address = models.TextField()
    contact_number = models.CharField(max_length=15)
    doctor_in_charge = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Reimbursement(models.Model):
    user = models.ForeignKey(login, on_delete=models.CASCADE)
    date = models.DateField()
    description = models.TextField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    hospital_name = models.CharField(max_length=100)
    status = models.CharField(max_length=50, default='completed')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.description[:50]}"
    

class Invoice(models.Model):
    invoice_no = models.CharField(max_length=50, unique=True)
    date = models.DateField()
    hospital = models.ForeignKey(Hospital, on_delete=models.CASCADE, null=True, blank=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    gst_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_with_gst = models.DecimalField(max_digits=10, decimal_places=2)
    user = models.ForeignKey(login, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Invoice {self.invoice_no} - {self.hospital.name if self.hospital else 'No Hospital'}"
