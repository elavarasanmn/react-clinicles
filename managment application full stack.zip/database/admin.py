from django.contrib import admin
from .models import login,Hospital,WorkAssignment

# Register your models here.
admin.site.register(login)
admin.site.register(Hospital)
admin.site.register(WorkAssignment)