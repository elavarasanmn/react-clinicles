- [ ] search repo for redirect/auth loop patterns (LOGIN_URL, login_required, redirect chains)
- [x] identify loop: dashboard URL points to login_view which redirects back to itself when session exists
- [x] update login_view to render dashboard directly when already on /purplefish/superadmin/dashboard/
- [ ] manual test: logged-in user hits dashboard URL and confirm no infinite redirects
- [ ] manual test: logged-out user hits dashboard URL and confirm it shows login page / correct behavior

